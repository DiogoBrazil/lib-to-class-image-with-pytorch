from .image_class import train_model

__all__ = [
    "train_model"
]
